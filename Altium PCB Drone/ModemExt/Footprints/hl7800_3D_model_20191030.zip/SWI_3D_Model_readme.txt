3D Model is recommended to be imported as an ASSEMBLY.
3D model presents the product in nominal dimensions.  
Please refer to product PTS for tolerances.