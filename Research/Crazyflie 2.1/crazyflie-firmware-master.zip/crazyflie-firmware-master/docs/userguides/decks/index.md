---
title: Decks
page_id: decks-index
---

Crazyflie expansion decks add new sensors and functionality to the Crazyflie. The firmware part of each deck is implemented as a [deck driver](/userguides/deck/) and adds functionality spcific to the deck. Read more about the functionality and implementation of each deck in the list below.

* [Active Marker deck](/userguides/decks/active-marker-deck/)
