/* Note used by this port of uIP, but required for compilation. */

