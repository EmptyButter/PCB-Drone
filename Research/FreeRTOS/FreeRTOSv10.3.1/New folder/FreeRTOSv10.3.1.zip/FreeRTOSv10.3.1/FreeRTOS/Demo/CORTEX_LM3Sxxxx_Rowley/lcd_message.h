#ifndef LCD_MESSAGE_H
#define LCD_MESSAGE_H

typedef struct
{
	char *pcMessage;
} xOLEDMessage;

#endif /* LCD_MESSAGE_H */
